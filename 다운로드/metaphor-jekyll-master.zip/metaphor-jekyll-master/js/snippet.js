/**
 * Created by prio on 1/26/15.
 */
$(document).ready(function(){
    $('.header').parallax("50%",0.4);
})