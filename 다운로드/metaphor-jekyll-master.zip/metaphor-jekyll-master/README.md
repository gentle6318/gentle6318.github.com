
**This is a simple type blog theme made with Jekyll**

# Features

* Pinot-Boilerplate
* Pinot Buttons components
* Normalize css
* Modernizr added
* Parallax Effect
* Responsive
* Bootstrap Included
* Sass made


---

This is Metaphor.
