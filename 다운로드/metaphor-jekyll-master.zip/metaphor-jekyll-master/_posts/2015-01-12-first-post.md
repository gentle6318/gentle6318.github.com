---
layout: post
title:  "My First Blog Post"
date:   2015-01-12 23:25:05
author: Mahabub Islam
categories: First Blog
image: true
---



This is my first writing in this **Blog** , I was really looking a place  to write down my thoughts and my experiences which I learn along my personal and mostly my career life .

{% if page.image %}
<div class="post-img">
<img class="img-responsive img-post" src=" {{site.baseurl}}/img/tiger.jpeg "/>
</div>
{% endif %}

Writing about something is really pleasurable but when it can be writing about the stuff I work with and the stuff that not only can help me but others too is much more like the not writing but drawing childish imaginations with touch of smile in your face .

I hope this blog can show `Codes` and yes some [link](#) and when needed a piece of Picture which is alright , possible .

This is Mahabub I. and take care .
